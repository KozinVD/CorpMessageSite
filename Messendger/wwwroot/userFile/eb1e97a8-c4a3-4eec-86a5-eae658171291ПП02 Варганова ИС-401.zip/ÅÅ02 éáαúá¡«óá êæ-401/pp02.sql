create database PP_02;
Use PP_02;
create table Role 
(
	ID int Identity PRIMARY KEY,
	title nvarchar(50) not null
);
Create table Employee
(
	ID int PRIMARY KEY not null,
	id_role int not null,
	lastname nvarchar(30) not null,
	[name] nvarchar(30) not null,
	patronymic nvarchar(30),
	[login] nvarchar(50) not null,
	[password] nvarchar(30) not null,
	last_entry date,
	type_entry nvarchar(50) not null,
	FOREIGN KEY (id_role) REFERENCES Role(ID)
);
Create table Client
(
	ID int PRIMARY KEY not null,
	lastname nvarchar(30) not null,
	[name] nvarchar(30) not null,
	patronymic nvarchar(30),
	pass_data_seria int not null,
	pass_data_number int not null,
	date_bith date not null,
	[address] nvarchar(100) not null,
	email nvarchar(50) not null,
	[password] nvarchar(50) not null,
);
Create table [Service]
(
	ID int PRIMARY KEY not null,
	title nvarchar(50) not null,
	code_service nvarchar(50) not null,
	[price_one_ hour] money not null,
	
);
Create table [Order]
(
	ID int PRIMARY KEY not null,
	code_order nvarchar(50) not null,
	date_create date not null,
	time_order time not null,
	id_client int not null,
	[status] nvarchar(20) not null,
	date_closed date,
	time_procat int not null,
	FOREIGN KEY (id_client) REFERENCES [Client](ID)
);
Create table Service_Order
(
	ID int Identity PRIMARY KEY,
	id_service int not null,
	id_order int not null,
	FOREIGN KEY (id_service) REFERENCES [Service](ID),
	FOREIGN KEY (id_order) REFERENCES [Order](ID)
);
create table Hostory_entry
(
	ID int Identity PRIMARY KEY,
	id_employee int not null,
	date_entry datetime not null,
	date_exit datetime not null,
	FOREIGN KEY (id_employee) REFERENCES [Employee](ID)
);
