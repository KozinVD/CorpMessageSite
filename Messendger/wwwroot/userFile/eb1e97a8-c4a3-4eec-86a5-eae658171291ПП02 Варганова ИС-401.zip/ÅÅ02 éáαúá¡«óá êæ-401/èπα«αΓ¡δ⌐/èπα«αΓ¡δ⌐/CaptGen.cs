﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using Color = System.Drawing.Color;


namespace Курортный
{
    internal class CaptGen
    {
        public static BitmapImage GenCap(int width, int height, string text)
        {
            //создание картинку по размерам в зависимости от текста
            Bitmap captchaImage = new Bitmap(width, height);
            //Класс для генерации "шума" , генерируется он с помшью рандома
            Graphics graphics = Graphics.FromImage(captchaImage);
            Random rd = new Random();
            graphics.DrawString(text, new Font("Arial", 18), 
                System.Drawing.Brushes.Aqua, new PointF(50, 50));
            int x1, y1, x2, y2;
            for (int i = 0; i <= 50; i++)
            {
                //По данными координатма 50 раз генеруются линии в разных
                //рандомных координатах
                x1 = rd.Next(width);
                y1 = rd.Next(height);
                x2 = rd.Next(width);
                y2 = rd.Next(height);
                graphics.DrawLine(new System.Drawing.Pen(ColorGenerate()), x1, y1, x2, y2);
            }
            int x, y;
            for (int i = 0; i < 100; i++)
            {
                //В данном случае генерируются точки 100 раз
                //тоже рандомно 
                x = rd.Next(width);
                y = rd.Next(height);
                captchaImage.SetPixel(x, y, ColorGenerate());
            }
            graphics.Flush();
            BitmapImage bitmapimage = new BitmapImage();
            using (MemoryStream memory = new MemoryStream())
            {
                //изображения с помошью класса MemoryStream потоком загружается
                //в память для отображения в окне капчи
                captchaImage.Save(memory, System.Drawing.Imaging.ImageFormat.Bmp);
                memory.Position = 0;
                bitmapimage.BeginInit();
                bitmapimage.StreamSource = memory;
                bitmapimage.CacheOption = BitmapCacheOption.OnLoad;
                bitmapimage.EndInit();
            }
            return bitmapimage;
        }
        //метод генерации цвета
        static Color ColorGenerate()
        {
            Random rd = new Random();
            return Color.FromArgb(rd.Next(256), rd.Next(256), rd.Next(256));
        }
    }
}
