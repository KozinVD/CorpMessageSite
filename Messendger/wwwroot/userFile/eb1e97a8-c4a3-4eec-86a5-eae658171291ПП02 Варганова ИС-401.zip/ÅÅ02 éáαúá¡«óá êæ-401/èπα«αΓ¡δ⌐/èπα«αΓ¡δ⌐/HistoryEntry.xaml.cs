﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using Курортный.Entities;
using System.Windows.Threading;

namespace Курортный
{
    /// <summary>
    /// Логика взаимодействия для HistoryEntry.xaml
    /// </summary>
    public partial class HistoryEntry : Window
    {
        DispatcherTimer timers;
        public HistoryEntry()
        {
            InitializeComponent();
            //Вывод в Listview
            HistoryEntrLB.ItemsSource = App.DB.Hostory_entry.ToList();
            //Начало таймера, данные берутся из класса
            TimeSpan timer = TimeSpan.FromSeconds(allTime.Seconds);
            timerTxt.Text = timer.ToString(@"mm\:ss");
            timers = new DispatcherTimer();
            timers.Interval = TimeSpan.FromSeconds(1);
            timers.Tick += Timer_Tick;
            //начало тамймера
            timers.Start();
        }

        //Метод течения времени посекундно
        private void Timer_Tick(object sender, EventArgs e)
        {
            //если сеанс истечет
            if (allTime.Seconds <= 0)
            {
                //таймер останавливается
                timers.Stop();
                //таймер вновь перезагружается
                allTime.Refresh();
                MainWindow main = new MainWindow();
                main.Show();
                this.Close();
            }
            if (allTime.Seconds == 60)
            {
               allTime.MessageBoxic();
            }
            //течение секунды
           allTime.Seconds = allTime.Seconds - 1;
            //определяет секунду
            TimeSpan time = TimeSpan.FromSeconds(allTime.Seconds);
            //формат вывода времени
            timerTxt.Text = time.ToString(@"mm\:ss");
        }

        private void backBtn_Click(object sender, RoutedEventArgs e)
        {
            MainWindow main = new MainWindow(); 
            main.Show();
        }

        private void ComboBox_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
        }
    }
}
