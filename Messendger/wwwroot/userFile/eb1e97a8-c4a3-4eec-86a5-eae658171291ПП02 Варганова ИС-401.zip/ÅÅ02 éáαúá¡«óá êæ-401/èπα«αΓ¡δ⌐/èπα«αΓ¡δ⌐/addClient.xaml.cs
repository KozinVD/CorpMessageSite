﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using Курортный.Entities;

namespace Курортный
{
    /// <summary>
    /// Логика взаимодействия для addClient.xaml
    /// </summary>
    public partial class addClient : Window
    {
        public addClient()
        {
            InitializeComponent();
        }

        private void nextBtn_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                //Добавление данных клиента
                Client client = App.DB.Client.FirstOrDefault();
                client.email = txtLogin.Text;
                client.date_bith = birthdayDP.SelectedDate.Value;
                client.name = txtName.Text;
                client.password = txtPassword.Text;
                client.address = txtAdress.Text;
                client.pass_data_seria = int.Parse(txtPass.Text);
                client.patronymic = txtPatronymic.Text;
                client.ID = 1;
                //Добавление и сохранение в БД
                App.DB.Client.Add(client);
                App.DB.SaveChanges();
                MessageBox.Show("Данные добавлены", "Сообщение",
                    MessageBoxButton.OK, MessageBoxImage.Information);
                Service service = new Service();
                service.Show();
                this.Close();
                
            }
            catch (Exception ex) { MessageBox.Show("Ошибка добавления данных",
                "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error); }
        }
    }
}
