﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Xml.Linq;
using Курортный.Entities;

namespace Курортный
{
    /// <summary>
    /// Логика взаимодействия для addService.xaml
    /// </summary>
    public partial class addService : Window
    {
        public addService()
        {
            InitializeComponent();
        }

        private void nextBtn_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                //Добавление данных сервиса
                Курортный.Entities.Service service = App.DB.Service.FirstOrDefault();
                service.title = txtTitle.Text;
                service.code_service = txtCode.Text;
                service.price_one__hour = decimal.Parse(txtPrice.Text);
                //Добавление и сохранение в БД
                App.DB.Service.Add(service);
                App.DB.SaveChanges();
                MessageBox.Show("Данные добавлены", "Сообщение", MessageBoxButton.OK, MessageBoxImage.Information);
                Service services = new Service();
                services.Show();
                this.Close();

            }
            catch (Exception ex) { MessageBox.Show("Ошибка добавления данных", 
                "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error); }
        }
    }
}
